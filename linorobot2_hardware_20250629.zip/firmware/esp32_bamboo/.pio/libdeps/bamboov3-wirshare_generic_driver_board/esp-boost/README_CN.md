[![Arduino Lint](https://github.com/espressif/esp-boost/actions/workflows/arduino_lint.yml/badge.svg)](https://github.com/espressif/esp-boost/actions/workflows/arduino_lint.yml) [![Version Consistency](https://github.com/espressif/esp-boost/actions/workflows/check_lib_versions.yml/badge.svg)](https://github.com/espressif/esp-boost/actions/workflows/check_lib_versions.yml)

**最新 Arduino 库版本**: [![GitHub Release](https://img.shields.io/github/v/release/espressif/esp-boost)](https://github.com/espressif/esp-boost/releases)

**最新 Espressif 组件版本**: [![Espressif Release](https://components.espressif.com/components/espressif/esp-boost/badge.svg)](https://components.espressif.com/components/espressif/esp-boost)

# ESP Boost C++ Library

* [English Version](./README.md)

## 概述

esp-boost 是 Espressif 基于 [Boost](https://github.com/boostorg/boost) 移植的 C++ 库，用于 ESP 系列 SoCs（ESP32、ESP32-S3、ESP32-P4 等）开发 C++ 应用。它支持多种开发框架，包括 [ESP-IDF](https://github.com/espressif/esp-idf)、[Arduino](https://github.com/espressif/arduino-esp32) 和 [MicroPython](https://github.com/micropython/micropython)。

> [!NOTE]
> - esp-boost 移植的 Boost 库官方版本为 `1.87.0`。
> - esp-boost 中的绝大部分库都是直接从官方仓库拷贝而来。由于部分库具有平台依赖性，为了能够在 ESP-IDF 上进行编译，我们进行了必要的修改（如在 `config` 中新增 [esp32.hpp](src/boost/config/platform/esp32.hpp) 和 [esp32.cpp](src/boost/config/src/esp32.cpp)）。所有修改的地方都会使用 `esp32` 注释标记。

> [!WARNING]
> - esp-boost 目前还未完全移植 Boost 中的所有库，仅移植了部分常用功能，具体支持情况请参考 [支持的库](#支持的库)。
> - 由于 Boost 很多库需要使用 C++ 的 `Exception` 和 `RTTI` 特性，而 ESP-IDF 默认禁用这两个特性，因此用户需要在 `menuconfig` 中开启 `CONFIG_COMPILER_CXX_EXCEPTIONS` 和 `CONFIG_COMPILER_CXX_RTTI` 配置选项。

## 目录

- [ESP Boost C++ Library](#esp-boost-c-library)
  - [概述](#概述)
  - [目录](#目录)
  - [如何使用](#如何使用)
  - [支持的库](#支持的库)
  - [常见问题及解答](#常见问题及解答)

## 如何使用

📖 以下是 esp-boost 在不同开发环境中的使用指南：

* [ESP-IDF](./docs/envs/use_with_idf_cn.md)
* [Arduino IDE](./docs/envs/use_with_arduino_cn.md)

## 支持的库

📋 以下是 esp-boost 支持的库列表：

> [!NOTE]
> 下面的表格中，图标和符号的含义如下：
> - ✅：表示该库已完全移植，并且内部使用官方的示例和测试进行了完整的验证。
> - ⚠️：表示该库仅移植了源码，但内部并未进行完整的验证测试。
> - ❌：表示没有相关的示例或测试。

|    **名称**     | **状态** |                                   **文档**                                    |                                                    **示例**                                                    |                                                                        **测试**                                                                         |
| --------------- | -------- | ----------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| signals2        | ✅️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/signals2/index.html)        | [内部](./test_apps/signals2/example/) / [官方](https://github.com/boostorg/signals2/tree/boost-1.87.0/example) | [内部](./test_apps/signals2/test/) / [官方](https://github.com/boostorg/signals2/tree/boost-1.87.0/test)                                                |
| thread          | ✅️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/thread/index.html)          | [内部](./test_apps/thread/example/) / [官方](https://github.com/boostorg/thread/tree/boost-1.87.0/example)     | [内部 1](./test_apps/thread/test_common/) & [内部 2](./test_apps/thread/test_more/) / [官方](https://github.com/boostorg/thread/tree/boost-1.87.0/test) |
| algorithm       | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/algorithm/index.html)       | [官方](https://github.com/boostorg/algorithm/tree/boost-1.87.0/example)                                        | [官方](https://github.com/boostorg/algorithm/tree/boost-1.87.0/test)                                                                                    |
| align           | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/align/index.html)           | ❌                                                                                                              | [官方](https://github.com/boostorg/align/tree/boost-1.87.0/test)                                                                                        |
| array           | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/array/index.html)           | ❌                                                                                                              | [官方](https://github.com/boostorg/array/tree/boost-1.87.0/test)                                                                                        |
| assert          | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/assert/index.html)          | ❌                                                                                                              | [官方](https://github.com/boostorg/assert/tree/boost-1.87.0/test)                                                                                       |
| atomic          | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/atomic/index.html)          | ❌                                                                                                              | [官方](https://github.com/boostorg/atomic/tree/boost-1.87.0/test)                                                                                       |
| bind            | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/bind/index.html)            | ❌                                                                                                              | [官方](https://github.com/boostorg/bind/tree/boost-1.87.0/test)                                                                                         |
| chrono          | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/chrono/index.html)          | [官方](https://github.com/boostorg/chrono/tree/boost-1.87.0/example)                                           | [官方](https://github.com/boostorg/chrono/tree/boost-1.87.0/test)                                                                                       |
| config          | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/config/index.html)          | ❌                                                                                                              | [官方](https://github.com/boostorg/config/tree/boost-1.87.0/test)                                                                                       |
| concept_check   | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/concept_check/index.html)   | ❌                                                                                                              | [官方](https://github.com/boostorg/concept_check/tree/boost-1.87.0/test)                                                                                |
| container       | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/container/index.html)       | [官方](https://github.com/boostorg/container/tree/boost-1.87.0/example)                                        | [官方](https://github.com/boostorg/container/tree/boost-1.87.0/test)                                                                                    |
| container_hash  | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/container_hash/index.html)  | ❌                                                                                                              | [官方](https://github.com/boostorg/container_hash/tree/boost-1.87.0/test)                                                                               |
| core            | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/core/index.html)            | ❌                                                                                                              | [官方](https://github.com/boostorg/core/tree/boost-1.87.0/test)                                                                                         |
| date_time       | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/date_time/index.html)       | [官方](https://github.com/boostorg/date_time/tree/boost-1.87.0/example)                                        | [官方](https://github.com/boostorg/date_time/tree/boost-1.87.0/test)                                                                                    |
| describe        | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/describe/index.html)        | [官方](https://github.com/boostorg/describe/tree/boost-1.87.0/example)                                         | [官方](https://github.com/boostorg/describe/tree/boost-1.87.0/test)                                                                                     |
| detail          | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/detail/index.html)          | ❌                                                                                                              | [官方](https://github.com/boostorg/detail/tree/boost-1.87.0/test)                                                                                       |
| exception       | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/exception/index.html)       | [官方](https://github.com/boostorg/exception/tree/boost-1.87.0/example)                                        | [官方](https://github.com/boostorg/exception/tree/boost-1.87.0/test)                                                                                    |
| function        | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/function/index.html)        | [官方](https://github.com/boostorg/function/tree/boost-1.87.0/example)                                         | [官方](https://github.com/boostorg/function/tree/boost-1.87.0/test)                                                                                     |
| function_types  | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/function_types/index.html)  | [官方](https://github.com/boostorg/function_types/tree/boost-1.87.0/example)                                   | [官方](https://github.com/boostorg/function_types/tree/boost-1.87.0/test)                                                                               |
| fusion          | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/fusion/index.html)          | [官方](https://github.com/boostorg/fusion/tree/boost-1.87.0/example)                                           | [官方](https://github.com/boostorg/fusion/tree/boost-1.87.0/test)                                                                                       |
| io              | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/io/index.html)              | ❌                                                                                                              | [官方](https://github.com/boostorg/io/tree/boost-1.87.0/test)                                                                                           |
| integer         | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/integer/index.html)         | ❌                                                                                                              | [官方](https://github.com/boostorg/integer/tree/boost-1.87.0/test)                                                                                      |
| intrusive       | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/intrusive/index.html)       | [官方](https://github.com/boostorg/intrusive/tree/boost-1.87.0/example)                                        | [官方](https://github.com/boostorg/intrusive/tree/boost-1.87.0/test)                                                                                    |
| iterator        | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/iterator/index.html)        | [官方](https://github.com/boostorg/iterator/tree/boost-1.87.0/example)                                         | [官方](https://github.com/boostorg/iterator/tree/boost-1.87.0/test)                                                                                     |
| lexical_cast    | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/lexical_cast/index.html)    | [官方](https://github.com/boostorg/lexical_cast/tree/boost-1.87.0/example)                                     | [官方](https://github.com/boostorg/lexical_cast/tree/boost-1.87.0/test)                                                                                 |
| move            | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/move/index.html)            | [官方](https://github.com/boostorg/move/tree/boost-1.87.0/example)                                             | [官方](https://github.com/boostorg/move/tree/boost-1.87.0/test)                                                                                         |
| mp11            | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/mp11/index.html)            | ❌                                                                                                              | [官方](https://github.com/boostorg/mp11/tree/boost-1.87.0/test)                                                                                         |
| mpl             | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/mpl/index.html)             | [官方](https://github.com/boostorg/mpl/tree/boost-1.87.0/example)                                              | [官方](https://github.com/boostorg/mpl/tree/boost-1.87.0/test)                                                                                          |
| optional        | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/optional/index.html)        | ❌                                                                                                              | [官方](https://github.com/boostorg/optional/tree/boost-1.87.0/test)                                                                                     |
| parameter       | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/parameter/index.html)       | ❌                                                                                                              | [官方](https://github.com/boostorg/parameter/tree/boost-1.87.0/test)                                                                                    |
| predef          | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/predef/index.html)          | ❌                                                                                                              | [官方](https://github.com/boostorg/predef/tree/boost-1.87.0/test)                                                                                       |
| preprocessor    | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/preprocessor/index.html)    | ❌                                                                                                              | [官方](https://github.com/boostorg/preprocessor/tree/boost-1.87.0/test)                                                                                 |
| range           | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/range/index.html)           | ❌                                                                                                              | [官方](https://github.com/boostorg/range/tree/boost-1.87.0/test)                                                                                        |
| ratio           | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/ratio/index.html)           | [官方](https://github.com/boostorg/ratio/tree/boost-1.87.0/example)                                            | [官方](https://github.com/boostorg/ratio/tree/boost-1.87.0/test)                                                                                        |
| regex           | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/regex/index.html)           | [官方](https://github.com/boostorg/regex/tree/boost-1.87.0/example)                                            | [官方](https://github.com/boostorg/regex/tree/boost-1.87.0/test)                                                                                        |
| smart_ptr       | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/smart_ptr/index.html)       | [官方](https://github.com/boostorg/smart_ptr/tree/boost-1.87.0/example)                                        | [官方](https://github.com/boostorg/smart_ptr/tree/boost-1.87.0/test)                                                                                    |
| static_assert   | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/static_assert/index.html)   | [官方](https://github.com/boostorg/static_assert/tree/boost-1.87.0/example)                                    | [官方](https://github.com/boostorg/static_assert/tree/boost-1.87.0/test)                                                                                |
| system          | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/system/index.html)          | ❌                                                                                                              | [官方](https://github.com/boostorg/system/tree/boost-1.87.0/test)                                                                                       |
| test            | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/test/index.html)            | [官方](https://github.com/boostorg/test/tree/boost-1.87.0/example)                                             | [官方](https://github.com/boostorg/test/tree/boost-1.87.0/test)                                                                                         |
| throw_exception | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/throw_exception/index.html) | ❌                                                                                                              | [官方](https://github.com/boostorg/throw_exception/tree/boost-1.87.0/test)                                                                              |
| tokenizer       | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/tokenizer/index.html)       | [官方](https://github.com/boostorg/tokenizer/tree/boost-1.87.0/example)                                        | [官方](https://github.com/boostorg/tokenizer/tree/boost-1.87.0/test)                                                                                    |
| tuple           | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/tuple/index.html)           | ❌                                                                                                              | [官方](https://github.com/boostorg/tuple/tree/boost-1.87.0/test)                                                                                        |
| type_traits     | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/type_traits/index.html)     | ❌                                                                                                              | [官方](https://github.com/boostorg/type_traits/tree/boost-1.87.0/test)                                                                                  |
| typeof          | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/typeof/index.html)          | ❌                                                                                                              | [官方](https://github.com/boostorg/typeof/tree/boost-1.87.0/test)                                                                                       |
| utility         | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/utility/index.html)         | ❌                                                                                                              | [官方](https://github.com/boostorg/utility/tree/boost-1.87.0/test)                                                                                      |
| variant         | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/variant/index.html)         | ❌                                                                                                              | [官方](https://github.com/boostorg/variant/tree/boost-1.87.0/test)                                                                                      |
| variant2        | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/variant2/index.html)        | ❌                                                                                                              | [官方](https://github.com/boostorg/variant2/tree/boost-1.87.0/test)                                                                                     |
| winapi          | ⚠️       | [链接](https://www.boost.org/doc/libs/1_87_0/libs/winapi/index.html)          | ❌                                                                                                              | [官方](https://github.com/boostorg/winapi/tree/boost-1.87.0/test)                                                                                       |

## 常见问题及解答

🔍 下面列举了在不同开发环境中常见的问题：

* [Arduino IDE](./docs/envs/use_with_arduino_cn.md#常见问题及解答)

  * [Arduino 库的目录在哪儿？](./docs/envs/use_with_arduino_cn.md#arduino-库的目录在哪儿)
  * [arduino-eps32 的安装目录以及 SDK 的目录在哪儿？](./docs/envs/use_with_arduino_cn.md#arduino-eps32-的安装目录以及-sdk-的目录在哪儿)
  * [如何在 Arduino IDE 中安装 esp_lib_template？](./docs/envs/use_with_arduino_cn.md#如何在-arduino-ide-中安装-esp-boost)
  * [如何在 Arduino IDE 中选择和配置支持的开发板？](./docs/envs/use_with_arduino_cn.md#如何在-arduino-ide-中选择和配置支持的开发板)
  * [在 Arduino IDE 中打开串口调试器看不到日志信息或日志信息显示不全，如何解决？](./docs/envs/use_with_arduino_cn.md#在-arduino-ide-中打开串口调试器看不到日志信息或日志信息显示不全如何解决)
